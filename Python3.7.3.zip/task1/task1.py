import sys 
from collections import deque

string = ''

N = int(sys.argv[1])
M = int(sys.argv[2])
   


a = list(range(1,N+1))
print ("array : ",a)

for x in a:
    string += str(x)

arr = deque(string)
path = list(arr[0])



arr.rotate(-(M-1))

while arr[0] != string[0]:
    path.append(arr[0])
    arr.rotate(-(M-1))
    

print("path : ",path)
