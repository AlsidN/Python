import sys

a =[]

with open(sys.argv[1],'r') as f:
  for line in f:
      a.append(line[:-1])

a = [int(x) for x in a]
print(a)

m = sorted(a)[len(a) // 2]

print(sum(abs(v - m) for v in a))



