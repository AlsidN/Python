import math
import sys 



a = [] #список точки
b = [] #список круга
string_point = ''
string_circle = ''

x_point   = []
y_point   = []
x_circle  = []
y_circle  = []
r_circle  = []
####### создание списка x1 y1 x2 y2 #########
with open(sys.argv[2],'r') as f:
  for line in f:
      a.append(line[:-1])
    
for x in a: # каждый элемент
    string_point += x
    string_point += ' '
  
a.clear()
a = list(string_point)

del a[1::2] #удаляем каждый 2 символ

############ для круга№№№№№№№№№№
with open(sys.argv[1],'r') as file1:
  for l in file1:
      b.append(l[:-1])
   

for x in b: # для каждого элемента списка удаляем пробел
    string_circle += x
    string_circle += ' '
  
b.clear()
b = list(string_circle)

del b[1::2] #удаляем каждый 2 символ

#########################

x_point = a[::2]
y_point = a[1::2]

x_point = list(map(float, x_point))
y_point = list(map(float, y_point))

x_circle = b[::3]
y_circle = b[1::2]
r_circle = b[2::2]

x_circle = list(map(float, x_circle))
y_circle = list(map(float, y_circle))
r_circle = list(map(float, r_circle))

print(r_circle)

for x_p,y_p,x_c,y_c in zip(x_point,y_point,x_circle,y_circle):

    hypot = math.sqrt(((x_p - x_c)** 2) + ((y_p - y_c)** 2))
     
for otvet in r_circle:
    if hypot < otvet:
        print("1 - точка внутри")
    elif hypot == otvet:
        print("0 - точка лежит на окружности")
    elif hypot > otvet:
        print("2 - точка снаружи")

